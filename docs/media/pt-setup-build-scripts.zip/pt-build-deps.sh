#!/bin/bash

# bold green
color_ok='\e[1;32m'
# bold red
color_error='\e[1;31m'
# bold magenta
color_title='\e[1;35m'
color_none='\e[00m'

none='<none>'
current_section=$none
current_step=$none
exec_step=true

jobcount=-j`nproc`
script_name=`basename $0`

# ----------------------------------------------------------------------------------

show_help() {
printf "Usage:
    $script_name <starting section> [options]
    $script_name --help

Downloads, builds and installs all Photivo dependencies.

Possible starting section (in order of execution):
dnld-bin        Download binary dependencies.
unpack-bin      Unpack and install binary dependencies.
dnld-src        Download source code dependencies.
unpack-src      Unpack source code dependencies.
build-zlib      Build and install zlib.
build-png       Build and install libPNG.
build-jpeg      Build and install libJPEG.
build-tiff      Build and install libTIFF.
build-lcms      Build and install LCMS2.
build-iconv     Build and install libiconv.
build-expat     Build and install expat.
build-exiv      Build and install Exiv2.
build-fftw      Build and install FFTW.
build-gm        Build and install GraphicsMagick.
build-lqr       Build and install libLQR (Liquid Rescale).
build-lensfun   Build and install Lensfun.

Special starting section:
full            Execute all sections from the beginning.
build-all       Execute all the \"build-*\" sections.

Options

-7=<dir>, --7zip=<dir>
            Directory where the 7-Zip executable (7z.exe) is located. May be
            omitted when 7-Zip is in the environment's search path.
            The path can be given in MSys or native notation. Note that native
            paths must always be quoted because of the backslash path
            delimiters.
-a, --auto  Automatic mode. Does not ask questions.
-o, --only  Executes only the specified section. Usually that and all following
            sections are executed.
-j=<jobcount>, --jobs=<jobcount>
            Force a job count for make. Usually make runs as many jobs as
            processor cores are available.

"
}

terminate() {
    echo "See the tutorial at:"
    echo "    http://photivo.org/download/windows#compiling_photivo"
    exit $1
}

# ----------------------------------------------------------------------------------

unset start_at
unset dir_7z
auto_mode=false
only_mode=false

for i in "$@"; do
    case $i in
        -h|--help)
            show_help
            terminate 0
        ;;
        -7=*|--7zip=*)
            dir_7z="${i#*=}"
            dir_7z=cygpath "$dir_7z" -u
            shift
        ;;
        -a|--auto)
            auto_mode=true
            shift
        ;;
        -o|--only)
            only_mode=true
            shift
        ;;
        -j=*|--jobs=*)
            jobcount="${i#*=}"
            shift
        ;;
        -*)
            printf "${color_error}Unknown option: $i.${color_none}\n"
            show_help
            terminate 1
        ;;
        *)
            if [[ "$start_at" != "" ]]; then
                printf "${color_error}More than one starting section specified.${color_none}\n"
                show_help
                terminate 1
            fi
            start_at=$1
            shift
        ;;
    esac
done

if [[ "$start_at" == "" ]]; then
    printf "${color_error}Starting section is missing.${color_none}\n"
    show_help
    terminate 1
fi

# ----------------------------------------------------------------------------------

bitness_ok=false
if [[ "$tc_bitness" == "32" || "$tc_bitness" == "64" ]]; then bitness_ok=true; fi

if [[ "$tc_name" == "" || $bitness_ok == false || "$devpath" == "" ]]; then
    printf "${color_error}Toolchain configuration has errors!${color_none}\n"
    echo "Run switchtc to activate a proper toolchain."
    terminate 1
fi

if ! mkdir -p $devpath/bin $devpath/lib $devpath/include $devpath/src; then
    printf "${color_error}Could not create necessary directories in $devpath${color_none}\n"
    terminate 1
fi

# ----------------------------------------------------------------------------------

if [[ "$dir_7z" != "" ]]; then PATH="$PATH:$dir_7z"; fi

needed_cmds=(7za cmake make pkg-config tar unzip)
cmds_ok=true
for command in "${needed_cmds[@]}"; do 
    if ! which $command >/dev/null 2>&1; then
        printf "${color_error}Command "$command" not found.${color_none}\n"
        cmds_ok=false
    fi
done
if [[ $cmds_ok == false ]]; then terminate 1; fi

# ----------------------------------------------------------------------------------

msys1_config_guess='#!/bin/sh
UNAME_MACHINE=`(uname -m) 2>/dev/null` || UNAME_MACHINE=unknown
echo ${UNAME_MACHINE}-pc-mingw32'

bin_names=(\
'gettext-runtime-dev' \
'gettext-runtime' \
'glib-dev' \
'glib' \
'Qt'\
)
bin64_urls=(\
http://ftp.gnome.org/pub/gnome/binaries/win64/dependencies/gettext-runtime-dev_0.18.1.1-2_win64.zip \
http://ftp.gnome.org/pub/gnome/binaries/win64/dependencies/gettext-runtime_0.18.1.1-2_win64.zip \
http://ftp.gnome.org/pub/gnome/binaries/win64/glib/2.26/glib-dev_2.26.1-1_win64.zip \
http://ftp.gnome.org/pub/gnome/binaries/win64/glib/2.26/glib_2.26.1-1_win64.zip \
http://downloads.sourceforge.net/project/qtx64/qt-x64/5.4.0/mingw-4.9/seh/qt-5.4.0-x64-mingw492r0-seh-compact.7z \
)
bin64_filenames=(\
gettext-runtime-dev_0.18.1.1-2_win64.zip \
gettext-runtime_0.18.1.1-2_win64.zip \
glib-dev_2.26.1-1_win64.zip \
glib_2.26.1-1_win64.zip \
qt-5.4.0-x64-mingw492r0-seh-compact.7z \
)
bin32_urls=(\
http://ftp.gnome.org/pub/gnome/binaries/win32/dependencies/gettext-runtime-dev_0.18.1.1-2_win32.zip \
http://ftp.gnome.org/pub/gnome/binaries/win32/dependencies/gettext-runtime_0.18.1.1-2_win32.zip \
http://ftp.acc.umu.se/pub/gnome/binaries/win32/glib/2.28/glib-dev_2.28.8-1_win32.zip \
http://ftp.acc.umu.se/pub/gnome/binaries/win32/glib/2.28/glib_2.28.1-1_win32.zip \
http://downloads.sourceforge.net/project/qtx64/qt-x86/5.4.0/mingw-4.9/sjlj/qt-5.4.0-x86-mingw492r0-sjlj-compact.7z \
)
bin32_filenames=(\
gettext-runtime-dev_0.18.1.1-2_win32.zip \
gettext-runtime_0.18.1.1-2_win32.zip \
glib-dev_2.28.8-1_win32.zip \
glib_2.28.1-1_win32.zip \
qt-5.4.0-x86-mingw492r0-sjlj-compact.7z \
)
bin_filename_patterns=(\
"gettext-runtime-dev_*" \
"gettext-runtime_*" \
"glib-dev_*" \
"glib_*" \
"qt-5*7z" \
)

src_names=(\
'zlib' \
'libpng' \
'libjpeg' \
'libtiff' \
'lcms2' \
'libiconv' \
'expat' \
'exiv2' \
'fftw' \
'GraphicsMagick' \
'liblqr' \
'lensfun' \
)
src_urls=(\
http://zlib.net/zlib-1.2.8.tar.gz \
http://downloads.sourceforge.net/project/libpng/libpng16/1.6.15/libpng-1.6.15.tar.xz \
http://www.ijg.org/files/jpegsrc.v9a.tar.gz \
ftp://ftp.remotesensing.org/pub/libtiff/tiff-4.0.3.tar.gz \
http://downloads.sourceforge.net/project/lcms/lcms/2.6/lcms2-2.6.tar.gz \
http://ftp.gnu.org/pub/gnu/libiconv/libiconv-1.14.tar.gz \
http://downloads.sourceforge.net/project/expat/expat/2.1.0/expat-2.1.0.tar.gz \
http://www.exiv2.org/exiv2-0.24.tar.gz \
ftp://ftp.fftw.org/pub/fftw/fftw-3.3.4.tar.gz \
ftp://ftp.graphicsmagick.org/pub/GraphicsMagick/1.3/GraphicsMagick-1.3.20.tar.xz \
http://liblqr.wdfiles.com/local--files/en:download-page/liblqr-1-0.4.2.tar.bz2 \
http://downloads.sourceforge.net/project/lensfun/0.2.8/lensfun-0.2.8.tar.bz2 \
)
src_filenames=(\
zlib-1.2.8.tar.gz \
libpng-1.6.15.tar.xz \
jpegsrc.v9a.tar.gz \
tiff-4.0.3.tar.gz \
lcms2-2.6.tar.gz \
libiconv-1.14.tar.gz \
expat-2.1.0.tar.gz \
exiv2-0.24.tar.gz \
fftw-3.3.4.tar.gz \
GraphicsMagick-1.3.20.tar.xz \
liblqr-1-0.4.2.tar.bz2 \
lensfun-0.2.8.tar.bz2 \
)
src_name_patterns=(\
"zlib-*" \
"libpng-*" \
"jpeg*" \
"tiff-*" \
"lcms2-*" \
"libiconv-1*" \
"expat-2.*" \
"exiv2-*" \
"fftw-3*" \
"GraphicsMagick-1.*" \
"liblqr-1*" \
"lensfun-*" \
)

# ----------------------------------------------------------------------------------

setup_step() {
    exec_step=true
    current_step=$1
    printf "\n${color_title}$current_step starts.${color_none}\n"
}

handle_status() {
    if [[ $1 == 0 ]]; then
        exec_step=false
        printf "${color_ok}$current_step succeeded.${color_none}\n"
        if [[ $only_mode == true ]]; then exit 0; fi
    else
        printf "${color_error}$current_step failed.${color_none}\n"
        if [[ $auto_mode == false ]]; then
            read -n 1 -p "Do you want to try again? (y/n)" repeat
            if [[ ("$repeat" != "y") && ("$repeat" != "Y") ]]; then
                if [[ $current_step != $none ]]; then
                    printf "\nYou can restart the script at this section with:\n"
                    printf "    $script_name $current_section\n"
                fi
                terminate $1
            fi
        fi
    fi
}

unpack() {
    if [[ $1 == *.7z ]]; then
        7za x -y `cygpath $1 -w`
    elif [[ $1 == *.zip ]]; then
        unzip -o $1
    else
        tar -xf $1
    fi
    handle_status $?
}

sweep_dirs() {
    for dirname in `find . -maxdepth 1 -name "$1" -type d`; do
        bakname=_old_`basename $dirname`
        if [[ -e $bakname ]]; then rm -rf $bakname; fi
        mv $dirname $bakname
    done
}

newest() {
    for dirname in `find . -maxdepth 1 -name "$1" -type d | sort -r -V`; do
        echo `basename $dirname`
        break
    done
}

# ----------------------------------------------------------------------------------

case $start_at in
# ----------------------------------------------------------------------------------
'dnld-bin'|'full')
current_section='dnld-bin'
cd $devpath
only_mode_bak=$only_mode
only_mode=false

if [[ "$tc_bitness" == "64" ]]; then
    for i in "${!bin_names[@]}"; do 
        setup_step "Downloading ${bin_names[$i]}"
        while [[ $exec_step == true ]]; do
            sweep_dirs "${bin_filename_patterns[$i]}"
            /usr/bin/wget -nv --show-progress --progress=bar "${bin64_urls[$i]}"
            handle_status $?
        done
    done
elif [[ "$tc_bitness" == "32" ]]; then
    for i in "${!bin_names[@]}"; do 
        setup_step "Downloading ${bin_names[$i]}"
        while [[ $exec_step == true ]]; do
            sweep_dirs "${bin_filename_patterns[$i]}"
            /usr/bin/wget -nv --show-progress --progress=bar "${bin32_urls[$i]}"
            handle_status $?
        done
    done
fi

only_mode=$only_mode_bak
if [[ $only_mode == true ]]; then exit 0; fi
;&

# ----------------------------------------------------------------------------------
'unpack-bin')
current_section='unpack-bin'
cd $devpath
only_mode_bak=$only_mode
only_mode=false

if [[ "$tc_bitness" == "64" ]]; then
    for i in "${!bin_names[@]}"; do 
        setup_step "Unpacking ${bin_names[$i]}"
        while [[ $exec_step == true ]]; do
            unpack "${bin64_filenames[$i]}"
        done
    done
elif [[ "$tc_bitness" == "32" ]]; then
    for i in "${!bin_names[@]}"; do 
        setup_step "Unpacking ${bin_names[$i]}"
        while [[ $exec_step == true ]]; do
            unpack "${bin32_filenames[$i]}"
        done
    done
fi

# Special treatment for glib .pc files.
# They contain a hard coded path that needs to be adjusted.
for g in gio-2.0.pc gio-windows-2.0.pc glib-2.0.pc gmodule-2.0.pc gmodule-no-export-2.0.pc gobject-2.0.pc gthread-2.0.pc; do
    sed -i "s/^prefix=.*$/prefix=$(echo `cygpath -m $devpath` | sed -e 's/[\/&]/\\&/g')/" $devpath/lib/pkgconfig/$g
done

# Special treatment for qt
if [[ -e qt ]]; then
    rm -rf qt || {
        printf "\n${color_error}Failed to delete existing qt directory.${color_none}\n"
        terminate 1
    }
fi
mv `find . -maxdepth 1 -name 'qt-5*' -type d | sort -r -V` qt || {
    printf "\n${color_error}Failed to rename unpacked qt directory.${color_none}\n"
    terminate 1
}
cd $devpath/qt && qtbinpatcher || {
    printf "\n${color_error}QtBinPatcher failed.${color_none}\n"
    terminate 1
}

only_mode=$only_mode_bak
if [[ $only_mode == true ]]; then exit 0; fi
;&

# ----------------------------------------------------------------------------------
'dnld-src')
current_section='dnld-src'
cd $devpath/src
only_mode_bak=$only_mode
only_mode=false

[[ -e $devpath/src ]] || mkdir $devpath/src

for i in "${!src_names[@]}"; do 
    setup_step "Downloading ${src_names[$i]}"
    while [[ $exec_step == true ]]; do
        sweep_dirs "${src_name_patterns[$i]}"
        /usr/bin/wget -nv --show-progress --progress=bar "${src_urls[$i]}"
        handle_status $?
    done
done

only_mode=$only_mode_bak
if [[ $only_mode == true ]]; then exit 0; fi
;&

# ----------------------------------------------------------------------------------
'unpack-src')
current_section='unpack-src'
cd $devpath/src
only_mode_bak=$only_mode
only_mode=false

for i in "${!src_names[@]}"; do 
    setup_step "Unpacking ${src_names[$i]}"
    while [[ $exec_step == true ]]; do
        sweep_dirs "${src_name_patterns[$i]}"
        unpack "${src_filenames[$i]}"
    done
done

only_mode=$only_mode_bak
if [[ $only_mode == true ]]; then exit 0; fi
;&

# ----------------------------------------------------------------------------------
'build-zlib'|'build-all')
current_section='build-zlib'
setup_step 'Building zlib'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "zlib-*"` && \
    make $jobcount -f win32/Makefile.gcc && \
    cp -v zlib1.dll $devpath/bin && \
    cp -v zconf.h zlib.h $devpath/include && \
    cp -v libz.a libz.dll.a $devpath/lib
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-png')
current_section='build-png'
setup_step 'Building libpng'

fix_png_install() {
    png_files=(  libpng.a   libpng.dll   libpng.pc   libpng.dll.a   libpng-config)
    png16_files=(libpng16.a libpng16.dll libpng16.pc libpng16.dll.a libpng16-config)
    for i in "${!png_files[@]}"; do 
        if [[ ! -e ${png_files[$i]} ]]; then
            cp ${png16_files[$i]} ${png_files[$i]}
        fi
    done
    return 0
}

while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "libpng-*"` && \
    rm -rf _build && \
    mkdir _build && \
    cd _build && \
    cmake .. -G "MSYS Makefiles" -DCMAKE_INSTALL_PREFIX=$devpath -DCMAKE_BUILD_TYPE=release && \
    make $jobcount && \
    fix_png_install && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-jpeg')
current_section='build-jpeg'
setup_step 'Building libjpeg'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "jpeg-9*"` && \
    ./configure --prefix=$devpath && \
    make $jobcount && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-tiff')
current_section='build-tiff'
setup_step 'Building libtiff'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "tiff-*"` && \
    ./configure --prefix=$devpath && \
    make $jobcount && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-lcms')
current_section='build-lcms'
setup_step 'Building lcms2'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "lcms2-*"` && \
    ./configure --prefix=$devpath && \
    make $jobcount && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-iconv')
current_section='build-iconv'
setup_step 'Building libiconv'
while [[ $exec_step == true ]]; do
    # Everytime I build GNU software there is this voice in the back of my head
    # telling me to scream and run ... *Of course* libiconv is too stupid to detect
    # MSys2 even when it masquerades as MinGW! Why? Semms like it alone of all of
    # Photivo's autotools dependencies insists on the system type being lowercase
    # in the original MSYSTEM environment variable. Thank you, GNU, for causing endless
    # misery and suffering!
    # Replacing config.guess files with the fake MSys1 config.guess helps.
    cd $devpath/src && \
    cd `newest "libiconv-1*"` && \
    printf "$msys1_config_guess" > build-aux/config.guess && \
    cp build-aux/config.guess libcharset/build-aux/config.guess && \
    ./configure --prefix=$devpath CFLAGS="$CFLAGS -DPACKAGE_VERSION_STRING=1.14" && \
    make $jobcount && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-expat')
current_section='build-expat'
setup_step 'Building expat'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "expat-2*"` && \
    ./configure --prefix=$devpath && \
    make $jobcount && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-exiv')
current_section='build-exiv'
setup_step 'Building exiv2'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "exiv2-*"` && \
    rm -rf _build && \
    mkdir _build && \
    cd _build && \
    cmake .. -G "MSYS Makefiles" \
        -DCMAKE_INSTALL_PREFIX=$devpath \
        -DCMAKE_BUILD_TYPE=release \
        -DEXIV2_ENABLE_BUILD_SAMPLES=OFF && \
    make $jobcount && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-fftw')
current_section='build-fftw'
setup_step 'Building fftw'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "fftw-3*"` && \
    ./configure --prefix=$devpath --enable-shared --disable-static --enable-sse2 --enable-threads --with-combined-threads --with-our-malloc16 && \
    make $jobcount && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-gm')
current_section='build-gm'
setup_step 'Building GraphicsMagick'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "GraphicsMagick-1.*"` && \
    ./configure --prefix=$devpath --enable-shared --with-quantum-depth=16 --disable-static --without-modules --without-perl && \
    make $jobcount && \
    make install && \
    cp -r $devpath/include/GraphicsMagick/* $devpath/include
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-lqr')
current_section='build-lqr'
setup_step 'Building liblqr'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "liblqr-1-*"` && \
    ./configure --prefix=$devpath && \
    make $jobcount && \
    make install
    handle_status $?
done
;&

# ----------------------------------------------------------------------------------
'build-lensfun')
current_section='build-lensfun'
setup_step 'Building lensfun'
while [[ $exec_step == true ]]; do
    cd $devpath/src && \
    cd `newest "lensfun-*"` && \
    sed -i 's/INSTALL(FILES ${GLIB2_DLL} DESTINATION ${BINDIR})//' CMakeLists.txt && \
    rm -rf _build && \
    mkdir _build && \
    cd _build && \
    cmake .. -G "MSYS Makefiles" \
        -DCMAKE_INSTALL_PREFIX=$devpath \
        -DCMAKE_BUILD_TYPE=release \
        -DBUILD_FOR_SSE=ON \
        -DBUILD_FOR_SSE2=ON && \
    make $jobcount && \
    touch ../GLIB2_DLL-NOTFOUND && \
    make install && \
    cp -rf $devpath/src/lensfun/* $devpath && \
    cp -f $devpath/include/lensfun/lensfun.h $devpath/include && \
    rm -rf $devpath/src/lensfun/ && \
    rm -f $devpath/bin/GLIB2_DLL-NOTFOUND
    handle_status $?
done
;;

# ----------------------------------------------------------------------------------
*)
printf "${color_error}Unknow starting section "$start_at".${color_none}\n"
show_help 
terminate 1
;;
esac

printf "\n${color_ok}Success.${color_none}\n"
