#!/bin/bash

if [[ "$tc_base_dir" == "" ]]; then basedir=/c/tc; else basedir=$tc_base_dir; fi

sevenzip=$basedir/dev-tools/bin/7za
devdirname=gcc49
mingw64url=http://downloads.sourceforge.net/project/mingw-w64/Toolchains%20targetting%20Win64/Personal%20Builds/mingw-builds/4.9.2/threads-posix/seh/x86_64-4.9.2-release-posix-seh-rt_v3-rev1.7z
mingw64fname=x86_64-4.9.2-release-posix-seh-rt_v3-rev1.7z
mingw32url=http://downloads.sourceforge.net/project/mingw-w64/Toolchains%20targetting%20Win32/Personal%20Builds/mingw-builds/4.9.2/threads-posix/sjlj/i686-4.9.2-release-posix-sjlj-rt_v3-rev1.7z
mingw32fname=i686-4.9.2-release-posix-sjlj-rt_v3-rev1.7z

install64=false
install32=false

if [[ "$1" == "" ]]; then
    echo Usage: $0 [64] [32]
    exit 1
fi
for i in "$@"; do
    case $i in
        64)
        install64=true
        ;;
        32)
        install32=true
        ;;
        *)
        echo Unknown option: $i
        exit 1
        ;;
    esac
done

if [[ ! -d $basedir/$devdirname ]]; then
  mkdir $basedir/$devdirname || exit 1
fi

if [[ $install64 == true ]]; then
    if [[ -e $basedir/$devdirname/win64/bin/g++.exe ]]; then
        echo 64bit MinGW already installed.
    else
        cd $basedir/$devdirname && \
        wget $mingw64url && \
        $sevenzip x $mingw64fname && \
        mv mingw64 win64
        if [[ $? != 0 ]]; then
            echo Error installing 64bit MinGW.
            exit 1
        fi
    fi
    
    cd $basedir/$devdirname/win64 && \
    if [[ ! -d dev ]]; then mkdir dev; fi && \
    cd dev && \
    if [[ ! -d bin ]]; then mkdir bin; fi && \
    if [[ ! -d lib ]]; then mkdir lib; fi && \
    if [[ ! -d include ]]; then mkdir include; fi
    if [[ ! -d src ]]; then mkdir src; fi
fi

if [[ $install32 == true ]]; then
    if [[ -e $basedir/$devdirname/win32/bin/g++.exe ]]; then
        echo 32bit MinGW already installed.
    else
        cd $basedir/$devdirname && \
        wget $mingw32url && \
        $sevenzip x $mingw32fname && \
        mv mingw32 win32
        if [[ $? != 0 ]]; then
            echo Error installing 32bit MinGW.
            exit 1
        fi
    fi
    
    cd $basedir/$devdirname/win32 && \
    if [[ ! -d dev ]]; then mkdir dev; fi && \
    cd dev && \
    if [[ ! -d bin ]]; then mkdir bin; fi && \
    if [[ ! -d lib ]]; then mkdir lib; fi && \
    if [[ ! -d include ]]; then mkdir include; fi
    if [[ ! -d src ]]; then mkdir src; fi
fi

echo Installation complete.
