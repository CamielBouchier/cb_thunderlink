#!/bin/bash
if [[ "$tc_base_dir" == "" ]]; then basedir=/c/tc; else basedir=$tc_base_dir; fi

szipurl=http://downloads.sourceforge.net/project/sevenzip/7-Zip/9.20/7za920.zip
szipfname=7za920.zip
szipexe=7za.exe

cmakeurl=http://www.cmake.org/files/v3.1/cmake-3.1.0-win32-x86.zip
cmakefname=cmake-3.1.0-win32-x86.zip
cmakefnameinside=cmake-3.1.0-win32-x86
cmakeexe=cmake.exe


# Update MSys and install additional necessary packages
pacman -Su --noconfirm || {
    echo Error updating installed packages
    exit 1
}

pacman -S --noconfirm make autoconf automake libtool patch pkg-config mercurial unzip wget || {
    echo Error installing necessary packages for building.
    exit 1
}


if [[ ! -d $basedir/dev-tools/bin ]]; then
    mkdir $basedir/dev-tools/bin || exit 1
fi


# Install 7-Zip command line client
if [[ ! -e $basedir/dev-tools/bin/$szipexe ]]; then
    if [[ -e $basedir/$szipfname ]]; then rm -f $basedir/$szipfname; fi

    cd $basedir && \
    wget $szipurl && \
    unzip -o $szipfname $szipexe -d $basedir/dev-tools/bin
    
    if [[ $? != 0 ]]; then
        echo Error installing 7-Zip.
        exit 1
    fi
fi


# Install cmake
if [[ ! -e $basedir/dev-tools/bin/$cmakeexe ]]; then
    if [[ -e $basedir/$cmakefname ]]; then rm -f $basedir/$cmakefname; fi

    cd $basedir && \
    wget $cmakeurl && \
    unzip -o $cmakefname -d $basedir/dev-tools && \
    cp -rf dev-tools/$cmakefnameinside/* dev-tools && \
    rm -rf dev-tools/$cmakefnameinside

    if [[ $? != 0 ]]; then
        echo Error installing CMake.
        exit 1
    fi
fi


# Install toolchain scripts
if [[ ! -e $basedir/.hg ]]; then
    cd $basedir && \
    hg clone -U https://bitbucket.org/BrotherJohn/hbb-toolchain/ tmp && \
    mv tmp/.hg . && \
    rm -rf tmp && \
    hg up
else
    cd $basedir && hg pull -u
fi

if [[ $? != 0 ]]; then
    echo Error setting up toolchain management scripts.
    exit 1
fi


echo Installation complete.
